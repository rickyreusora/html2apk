# HTML2APK

Turns a website URL into an installable Android APK, using a [Trusted Web
Activity](https://developer.chrome.com/docs/android/trusted-web-activity/overview/)
(TWA) wrapper built with Google's [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap)
tooling. A TWA is a thin, Google-sanctioned native shell that launches Chrome
to render the page — much more maintainable than a hand-rolled WebView app.

This is an original implementation (own code, own branding) — not a copy of
any third-party "URL to APK" site.

## How it works

1. You submit a URL + app name (+ optional package id / colors / icon) through
   the web form.
2. The server writes a `twa-manifest.json` describing the Android app.
3. It generates a signing keystore (if one doesn't exist yet for that build)
   and shells out to the Bubblewrap CLI, which generates an Android Gradle
   project and runs `assembleRelease`.
4. The signed APK is served back for download.

## Requirements (install these on the machine that will actually run builds —
this does *not* run inside a locked-down sandbox with no internet access)

- **Node.js 18+**
- **JDK 17+** (`java -version`)
- **Android SDK**, with these installed via `sdkmanager`:
  - `platform-tools`
  - `platforms;android-34` (or whatever Bubblewrap currently targets)
  - `build-tools;34.0.0`
  - Set `ANDROID_HOME` (and `ANDROID_SDK_ROOT`) to the SDK path.
- Bubblewrap will also download its own private copy of the JDK/Android SDK
  the first time you run `npx @bubblewrap/cli doctor` if you'd rather not
  manage it yourself — run that once interactively before starting the
  server, so the license prompts are accepted ahead of time.

## Setup

```bash
cd html2apk
npm install
npx @bubblewrap/cli doctor   # first-time only; verifies/installs SDK + JDK
npm start                    # serves on http://localhost:3000
```

Then open `http://localhost:3000`, fill in the form, and submit. The first
build for a fresh environment will be slow (Gradle pulls dependencies); later
builds are much faster.

## Deploying on Railway

A `Dockerfile` is included that installs Node, a JDK, and the Android SDK
command-line tools, so Railway (or Render/Fly.io/any Docker host) can run
this directly — unlike Vercel, which only runs short-lived serverless
functions with no SDK/Gradle support.

1. Push this project to a GitHub repo.
2. In Railway: **New Project → GitHub Repository**, select the repo.
3. Railway detects the `Dockerfile` automatically and builds from it — no
   extra config needed. The first build will take a while (downloading the
   Android SDK components), subsequent deploys are faster thanks to layer
   caching.
4. Railway sets `PORT` automatically; `server/index.js` already reads
   `process.env.PORT`, so no changes needed there.
5. Once deployed, open the Railway-provided URL — the form should load and
   builds should work end-to-end.

Note: each APK build spins up a Gradle process that can be memory-hungry
(500MB-1GB+). If builds fail or get OOM-killed, bump the service's memory
allocation in Railway's settings.

## Important limitation: Digital Asset Links

A TWA only renders truly "full screen, no browser chrome" when the **target
website's owner** publishes a `/.well-known/assetlinks.json` file proving
they authorize your app's package + signing key to represent their domain.
Since this tool wraps *arbitrary* third-party URLs you don't control, that
verification will usually be missing — Chrome then falls back to showing a
small Custom Tabs toolbar at the top (this is what `fallbackType:
"customtabs"` in `server/lib/manifest.js` configures). This is expected and
is how Chrome enforces that only legitimate site owners get the fully
chromeless experience. If you're wrapping a site you own, add the
assetlinks.json file there and the generated app will go fully edge-to-edge
automatically — no server changes needed.

## Project layout

```
server/
  index.js          Express app entrypoint
  routes/build.js    POST /api/build, GET /api/build/:id, GET /api/download/:id
  lib/manifest.js    Builds the twa-manifest.json from form input
  lib/bubblewrap.js  Keystore generation + shells out to the Bubblewrap CLI
public/
  index.html / styles.css / app.js   The build form + polling UI
workdir/             Scratch dir per build (cleaned up after each build)
builds/              Finished .apk files, served for download
```

## Production notes

- Swap the in-memory `jobs` Map in `routes/build.js` for persistent storage
  (Redis, a DB table) if you need jobs to survive a server restart or want
  multiple server instances.
- Reuse one keystore per app/package id rather than minting a new one per
  build if users will want to ship updates to the same app later — Android
  requires the same signing key for updates to install over an existing app.
- Add rate limiting / auth before exposing this publicly — unrestricted APK
  building is a good way to burn CPU and bandwidth.
- Consider validating/sanitizing the submitted URL server-side (e.g. block
  `file://`, internal/private IP ranges) if this will be public-facing, to
  avoid SSRF-style abuse of your build server.
